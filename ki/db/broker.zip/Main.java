
import etcee.ki.agent.*;

import etcee.ki.jess.JessAgent;

import jess.RU;
import jess.Value;
import jess.ValueVector;
import jess.ReteException;

public
class Main
extends JessAgent
{
  public
  void
  handleRegisterNewBuyer(Object object)
  throws ReteException
  {
    AgentIdentity agentidentity = null;

    if (object instanceof String)
    {
      agentidentity = getAgentContext().getPublishedAgentIdentity((String)object);
    }
    else if (object instanceof AgentIdentity)
    {
      agentidentity = (AgentIdentity)object;
    }
    else if (object instanceof Value)
    {
      Value value = (Value)object;

      if (value.type() == RU.STRING)
      {
        agentidentity = getAgentContext().getPublishedAgentIdentity(value.stringValue());
      }
      else if (value.type() == RU.EXTERNAL_ADDRESS)
      {
        agentidentity = (AgentIdentity)value.externalAddressValue();
      }
    }

    ValueVector valuevector = new ValueVector();

    valuevector.add(new Value(RU.putAtom("buyer"), RU.ATOM));
    valuevector.add(new Value(RU.ORDERED_FACT, RU.DESCRIPTOR));
    valuevector.add(new Value(0, RU.INTEGER));
    valuevector.add(new Value(agentidentity, RU.EXTERNAL_ADDRESS));

    getRete().assert(valuevector);

    run();
  }

  public
  void
  handleRegisterNewSeller(Object object)
  throws ReteException
  {
    AgentIdentity agentidentity = null;

    if (object instanceof String)
    {
      agentidentity = getAgentContext().getPublishedAgentIdentity((String)object);
    }
    else if (object instanceof AgentIdentity)
    {
      agentidentity = (AgentIdentity)object;
    }
    else if (object instanceof Value)
    {
      Value value = (Value)object;

      if (value.type() == RU.STRING)
      {
        agentidentity = getAgentContext().getPublishedAgentIdentity(value.stringValue());
      }
      else if (value.type() == RU.EXTERNAL_ADDRESS)
      {
        agentidentity = (AgentIdentity)value.externalAddressValue();
      }
    }

    ValueVector valuevector = new ValueVector();

    valuevector.add(new Value(RU.putAtom("seller"), RU.ATOM));
    valuevector.add(new Value(RU.ORDERED_FACT, RU.DESCRIPTOR));
    valuevector.add(new Value(0, RU.INTEGER));
    valuevector.add(new Value(agentidentity, RU.EXTERNAL_ADDRESS));

    getRete().assert(valuevector);

    run();
  }

  public
  void
  initialize()
  {
  }

  public
  void
  start()
  {
    getAgentContext().publish("broker");

    initializeJessAgent("run.clp");
  }

  public
  void
  stop()
  {
    getAgentContext().unpublish();
  }

  public
  void
  conclude()
  {
  }
}
