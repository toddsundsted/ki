
import etcee.ki.agent.*;

import etcee.ki.jess.JessAgent;

import jess.ReteException;

import jess.RU;
import jess.Value;
import jess.ValueVector;
import jess.ReteException;

public
class Main
extends JessAgent
{
  public
  Value
  handleGetProducts()
  throws ReteException
  {
    ValueVector valuevector = new ValueVector();

    valuevector.add(new Value("Product 2", RU.STRING));
    valuevector.add(new Value("Product 3", RU.STRING));

    return new Value(valuevector, RU.LIST);
  }

  public
  void
  handleOrder(Object object)
  throws ReteException
  {
    String string = null;

    if (object instanceof String)
    {
      string = (String)object;
    }
    else if (object instanceof Value)
    {
      Value value = (Value)object;

      if (value.type() == RU.STRING)
      {
        string = value.stringValue();
      }
    }

    System.out.println("seller is accepting an order for " + string + "...");
  }

  public
  void 
  initialize()
  {
  }

  public
  void
  start()
  {
    try
    {
      Thread.sleep(1000);
    }
    catch (InterruptedException ex)
    {
    }

    getAgentContext().publish("seller");

    initializeJessAgent("run.clp");
  }

  public 
  void
  stop()
  {
    getAgentContext().unpublish();
  }

  public
  void
  conclude()
  {
  }
}
