
import etcee.ki.agent.*;

public
class Main
extends Agent
{
  private int nCounter = 0;

  private transient Thread thread = null;

  public
  String
  handleAbout()
  {
    return "A simple counter.  The 'Start' and 'Stop' messages start and stop\n" +
           "the counting process.";
  }

  public
  void
  handleStart()
  {
    if (thread != null) return;

    thread = new Thread()
      {
        public void
        run()
        {
          while (true)
          {
            System.out.println(++nCounter);

            try
            {
              Thread.sleep(1000);
            }
            catch (InterruptedException ex)
            {
              break;
            }
          }
        }
      };

    thread.start();
  }

  public
  void
  handleStop()
  {
    if (thread == null) return;

    thread.interrupt();
  }

  public
  void
  initialize()
  {
    nCounter = 0;
  }

  public
  void
  start()
  {
    getAgentContext().publish("counter");
  }

  public
  void
  stop()
  {
    getAgentContext().unpublish();
  }

  public
  void
  conclude()
  {
  }
}
