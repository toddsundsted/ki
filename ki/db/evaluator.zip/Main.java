
import etcee.ki.agent.*;

import etcee.ki.jess.JessAgent;

import jess.Value;
import jess.ReteException;

public
class Main
extends JessAgent
{
  public
  String
  handleAbout()
  {
    return "A Jess expression evaluator.  Send this agent an \"Evaluate\"\n" +
           "message with a single string parameter.";
  }

  public
  Value
  handleEvaluate(String stringCommand)
  throws ReteException
  {
    return evaluateCommand(stringCommand);
  }

  public
  void
  initialize()
  {
  }

  public
  void
  start()
  {
    getAgentContext().publish("evaluator");
  }

  public
  void
  stop()
  {
    getAgentContext().unpublish();
  }

  public
  void
  conclude()
  {
  }
}
