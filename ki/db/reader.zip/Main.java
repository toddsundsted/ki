
import etcee.ki.agent.*;

import etcee.ki.jess.JessAgent;

import jess.Jesp;
import jess.ReteException;

import java.io.InputStream;

public
class Main
extends JessAgent
{
  private transient boolean boolRunning = true;

  public
  String
  handleAbout()
  {
    return "A Jess command line agent.";
  }

  public
  void
  handleRun()
  {
    // Drop the priority of the command line reader thread.

    Thread.currentThread().setPriority(Thread.currentThread().getPriority() - 1);

    while (boolRunning)
    {
      try
      {
        new Jesp(System.in, getRete()).parse(true);
      }
      catch (ReteException ex)
      {
        ex.printStackTrace();
      }
    }
  }

  public
  void
  initialize()
  {
  }

  public
  void
  start()
  {
    initializeJessAgent("init.clp");

    getAgentContext().sendMessage(null, getAgentContext().getAgentIdentity(), new Message("Run"));
  }

  public
  void
  stop()
  {
    boolRunning = false;
  }

  public
  void
  conclude()
  {
  }
}
