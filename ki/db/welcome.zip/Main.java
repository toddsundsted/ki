
import etcee.ki.agent.*;

import java.awt.Button;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.List;
import java.awt.Panel;
import java.awt.TextArea;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

import java.util.Enumeration;

public
class Main
extends Agent
{
  private transient AgentControlFrame _agentcontrolframe = null;

  private transient Thread _thread = null;

  public
  String
  handleAbout()
  {
    return "Welcome to Ki for JavaWorld.  Use the \"Start\", \"Stop\",\n" +
           "and \"About\" buttons to send messages of the same name to the\n" +
           "selected agent.";
  }

  public
  void
  initialize()
  {
  }

  public
  void
  start()
  {
    showSplashFrame();
    showAgentControlFrame();

    getAgentContext().publish("welcome");
  }

  public
  void
  stop()
  {
    hideAgentControlFrame();
  }

  public
  void
  conclude()
  {
  }

  private
  void
  showSplashFrame()
  {
    SplashFrame splashframe = new SplashFrame("Welcome to Ki for JavaWorld");

    splashframe.setVisible(true);

    try
    {
      Thread.sleep(3000);
    }
    catch (InterruptedException ex)
    {
    }

    splashframe.setVisible(false);
  }

  private
  void
  showAgentControlFrame()
  {
    _agentcontrolframe = new AgentControlFrame("Welcome to Ki for JavaWorld");

    final List list = _agentcontrolframe._list;

    final AgentContext agentcontext = getAgentContext();

    _thread = new Thread()
      {
        public void
        run()
        {
          while (true)
          {
            int n = list.getSelectedIndex();

            String strT = n > -1 ? list.getItem(n) : null;

            list.removeAll();

            n = -1;

            int i = -1;

            Enumeration enumeration = agentcontext.getPublishedAgents();

            while (enumeration.hasMoreElements())
            {
              i++;

              String str = (String)enumeration.nextElement();

              if (str.equals(strT)) n = i;

              list.add(str);
            }

            if (n > -1) list.select(n);

            try
            {
              Thread.sleep(5000);
            }
            catch (InterruptedException ex)
            {
              break;
            }
          }
        }
      };

    _thread.start();

    ActionListener actionlistener = new ActionListener()
      {
        public
        void
        actionPerformed(ActionEvent actionevent)
        {
          String stringItem = _agentcontrolframe._list.getSelectedItem();

          if (stringItem != null)
          {
            AgentIdentity agentidentity = agentcontext.getPublishedAgentIdentity(stringItem);

            Message message = new Message(actionevent.getActionCommand());

            MessageResponse messageresponse = agentcontext.sendMessage(null,
                                                                       agentidentity,
                                                                       message);

            messageresponse.waitForResponse();

            if (messageresponse.getResponseCode() == MessageResponse.SUCCEEDED)
            {
              Object object = messageresponse.getResponse();

              if (object instanceof String)
              {
                String string = (String)object;

                new ResponseDialog(_agentcontrolframe, "The agent responded with:", string);
              }
            }
            else if (messageresponse.getResponseCode() == MessageResponse.FAILED)
            {
              Exception exception = messageresponse.getException();

              String string =
                "An exception occured " +
                "while sending the \"" + actionevent.getActionCommand() + "\" message " +
                "to the \"" + stringItem + "\" agent:\n\t" +
                exception.toString();

              new ResponseDialog(_agentcontrolframe, "The agent responded with:", string);
            }
          }
        }
      };

    _agentcontrolframe._buttonStart.addActionListener(actionlistener);
    _agentcontrolframe._buttonStop.addActionListener(actionlistener);
    _agentcontrolframe._buttonAbout.addActionListener(actionlistener);

    _agentcontrolframe.setVisible(true);
  }

  private
  void
  hideAgentControlFrame()
  {
    _thread.interrupt();

    _agentcontrolframe.setVisible(false);
  }
}
