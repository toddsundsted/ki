
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Frame;
import java.awt.Graphics;

class SplashFrame
extends Frame
{
  SplashFrame(String stringTitle)
  {
    super(stringTitle);

    setBackground(Color.white);

    setResizable(false);

    pack();
  }

  public
  void
  paint(Graphics graphics)
  {
    update(graphics);
  }

  public
  void
  update(Graphics graphics)
  {
    for (int i = 0; i < 256; i++)
    {
      graphics.setColor(new Color(0, 0, i));

      graphics.drawLine(0, i, 399, i);
    }

    graphics.setColor(Color.white);

    int y = 70;
    int x = 0;
    int w = 0;

    FontMetrics fontmetrics = null;

    graphics.setFont(new Font("sanserif", Font.PLAIN, 24));

    fontmetrics = graphics.getFontMetrics();

    w = fontmetrics.stringWidth("Welcome to Ki");

    x = (getSize().width - w) / 2;

    graphics.drawString("Welcome to Ki", x, y);

    y += fontmetrics.getHeight();

    w = fontmetrics.stringWidth("for JavaWorld");

    x = (getSize().width - w) / 2;

    graphics.drawString("for JavaWorld", x, y);

    y += fontmetrics.getHeight();

    graphics.setFont(new Font("serif", Font.PLAIN, 14));

    fontmetrics = graphics.getFontMetrics();

    w = fontmetrics.stringWidth("Copyright (c) 1998, Todd Sundsted");

    x = (getSize().width - w) / 2;

    graphics.drawString("Copyright (c) 1998, Todd Sundsted", x, y);

    y += fontmetrics.getHeight();
  }

  public
  Dimension
  getPreferredSize()
  {
    return new Dimension(400, 256);
  }
}
