
import java.awt.Button;
import java.awt.Color;
import java.awt.Dialog;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.TextArea;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowAdapter;

class ResponseDialog
extends Dialog
{
  private int top = 30;
  private int left = 10;
  private int bottom = 10;
  private int right = 10;

  ResponseDialog(Frame frame, String stringTitle, String stringBody)
  {
    super(frame, stringTitle, true);

    Button button = new Button("Dismiss");

    LightweightPanel lightweightpanel = new LightweightPanel();

    lightweightpanel.add(button);

    add(lightweightpanel, "South");

    TextArea textarea = new TextArea();

    add(textarea, "Center");

    pack();

    textarea.append(stringBody);

    textarea.setEditable(false);

    WindowAdapter windowadapter = new WindowAdapter()
      {
        public
        void
        windowClosing(WindowEvent windowevent)
        {
          ResponseDialog.this.setVisible(false);

          ResponseDialog.this.dispose();
        }
      };

    addWindowListener(windowadapter);

    ActionListener actionlistener = new ActionListener()
      {
        public
        void
        actionPerformed(ActionEvent actionevent)
        {
          ResponseDialog.this.setVisible(false);

          ResponseDialog.this.dispose();
        }
      };

    button.addActionListener(actionlistener);

    setResizable(false);

    setVisible(true);
  }

  public
  void
  update(Graphics graphics)
  {
    paint(graphics);

    super.update(graphics);
  }

  public
  void
  paint(Graphics graphics)
  {
    Dimension dimension = getSize();

    int h = dimension.height;
    int w = dimension.width;

    for (int y = 0; y < h; y++)
    {
      graphics.setColor(new Color(0, 0, (int)(y * 256.0 / h)));

      graphics.drawLine(0, y, w - 1, y);
    }

    super.paint(graphics);
  }

  public
  Insets
  getInsets()
  {
    return new Insets(top, left, bottom, right);
  }

  public
  Dimension
  getPreferredSize()
  {
    return new Dimension(600, 200);
  }
}
