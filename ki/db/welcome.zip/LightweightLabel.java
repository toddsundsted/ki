
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Rectangle;

class LightweightLabel
extends Component
{
  private Font _fontText = null;
  private Color _colorText = null;
  private String _stringText = null;

  LightweightLabel(Font fontText, Color colorText, String stringText)
  {
    _fontText = fontText;
    _colorText = colorText;
    _stringText = stringText;
  }

  public
  void
  update(Graphics graphics)
  {
    graphics.setFont(_fontText);
    graphics.setColor(_colorText);

    Dimension dimension = getSize();

    FontMetrics fontmetrics = getFontMetrics(_fontText);

    graphics.drawString(_stringText, 0, dimension.height - fontmetrics.getDescent() - 2);
  }

  public
  void
  paint(Graphics graphics)
  {
    update(graphics);
  }

  public
  Dimension
  getPreferredSize()
  {
    Font font = getFont();

    if (font == null)
    {
      return new Dimension(100, 40);
    }
    else
    {
      FontMetrics fontmetrics = getFontMetrics(font);

      return new Dimension(fontmetrics.stringWidth(_stringText) + 20,
                           fontmetrics.getHeight() + 10);
    }
  }
}
