
import java.awt.Container;
import java.awt.FlowLayout;

class LightweightPanel
extends Container
{
  LightweightPanel()
  {
    setLayout(new FlowLayout(FlowLayout.CENTER));
  }
}
