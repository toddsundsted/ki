
import java.awt.Button;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.Insets;
import java.awt.List;
import java.awt.Panel;

class AgentControlFrame
extends Frame
{
  List _list = new List();

  LightweightPanel _lightweightpanel = new LightweightPanel();

  Button _buttonStart = new Button("Start");
  Button _buttonStop = new Button("Stop");
  Button _buttonAbout = new Button("About");

  private int top = 30;
  private int left = 10;
  private int bottom = 10;
  private int right = 10;

  AgentControlFrame(String stringTitle)
  {
    super(stringTitle);

    setLayout(new BorderLayout());

    LightweightLabel lightweightlabel = new LightweightLabel(new Font("sanserif", Font.PLAIN, 18),
                                                             Color.white,
                                                             "Published Agents:");

    add(lightweightlabel, "North");

    add(_list, "Center");

    LightweightPanel foo = new LightweightPanel();

    foo.setLayout(new BorderLayout());

    LightweightLabel bar = new LightweightLabel(new Font("sanserif", Font.PLAIN, 12),
                                                Color.white,
                    "Select one of the published agents above and a message below:");

     bar = new LightweightLabel(new Font("sanserif", Font.PLAIN, 18),
                                                Color.white,
                                                "Messages:");

    foo.add(bar, "North");

    _lightweightpanel.add(_buttonStart);
    _lightweightpanel.add(_buttonStop);
    _lightweightpanel.add(_buttonAbout);

    foo.add(_lightweightpanel, "South");

    add(foo, "South");

    pack();
  }

  public
  void
  update(Graphics graphics)
  {
    paint(graphics);

    super.update(graphics);
  }

  public
  void
  paint(Graphics graphics)
  {
    Dimension dimension = getSize();

    int h = dimension.height;
    int w = dimension.width;

    for (int y = 0; y < h; y++)
    {
      graphics.setColor(new Color(0, 0, (int)(y * 256.0 / h)));

      graphics.drawLine(0, y, w - 1, y);
    }

    super.paint(graphics);
  }

  public
  Insets
  getInsets()
  {
    return new Insets(top, left, bottom, right);
  }

  public
  Dimension
  getPreferredSize()
  {
    return new Dimension(400, 512);
  }
}
